// Global Variables
export const API_KEY = '17d87095f2cdce0db3600b9659b0c621';
export const API_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxN2Q4NzA5NWYyY2RjZTBkYjM2MDBiOTY1OWIwYzYyMSIsInN1YiI6IjYxMWJlNzAzNGEwYjE5MDA0NWM2MmQ4NyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.I7bffZOYQCup48LfeLOQlzxYv0_EjSugb6lVmRglJ10';

//App titile
export const title = 'GoMovie';