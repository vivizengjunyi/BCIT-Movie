const Footer = () => {
    return (
        <footer>
            <p>&copy; GoMovie</p>
        </footer>
    )
}

export default Footer
